//
//  NewsfeedViewController.swift
//  csr-chat
//
//  Created by Brandon Sugarman on 5/23/19.
//  Copyright © 2019 Brandon Sugarman. All rights reserved.
//

import UIKit
import Firebase
class NewsfeedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var newsfeed: UITableView!
    
    var posts: Array<String>!
    var ref: DatabaseReference!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        // write code here -- return the number of cells in the table
        return posts.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // write code here -- let's create our individual cells
        let cell = tableView.dequeueReusableCell(withIdentifier: "customcell", for: indexPath)
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.font = cell.textLabel?.font.withSize(25)
        cell.textLabel?.textColor = UIColor.init(red: 15/255.0, green: 127/255.0, blue: 190/255.0, alpha: 1)
        cell.textLabel?.text = posts[indexPath.item]
        return cell

    }

    @objc func refresh() {
        ref = Database.database().reference().child("posts")
        self.posts = []
        
        ref.observeSingleEvent(of: DataEventType.value, with: {(snapshot) in
            for currPost in snapshot.children.allObjects as! [DataSnapshot] {
                let post = currPost.value as! String
                self.posts.append(post)
            }
            self.posts.reverse()
            self.newsfeed.reloadData()
        })
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        refresh()
        
        var timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(NewsfeedViewController.refresh), userInfo: nil, repeats: true)

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goToWritePost(_ sender: Any) {
        CSRMethods.app.changeScreens(id:"writepost")
    }
    
    @IBAction func goToHome(_ sender: Any) {
        CSRMethods.app.changeScreens(id: "home")
    }

    
    @IBOutlet weak var darkModeSwitch: UISwitch!
    
    @IBOutlet weak var tableView: UITableView!
    @IBAction func darkModeOn(_ sender: Any) {
        
        if darkModeSwitch.isOn {
            view.backgroundColor = UIColor.init(red: 55/255.0, green: 55/255.0, blue: 55/255.0, alpha: 1)
            
        } else {
            view.backgroundColor = UIColor.init(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 1)
        
}
}
}
