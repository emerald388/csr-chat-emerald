//
//  SignupViewController.swift
//  csr-chat
//
//  Created by Brandon Sugarman on 5/23/19.
//  Copyright © 2019 Brandon Sugarman. All rights reserved.
//

import UIKit
import Firebase 
class SignupViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func goBack(_ sender: Any) {
        CSRMethods.app.changeScreens(id: "home")
    }
    

    @IBOutlet weak var enterUsername: UITextField!
    @IBOutlet weak var enterEmail: UITextField!
    
    @IBOutlet weak var enterPassword: UITextField!
    
    @IBOutlet weak var confirmPassword: UITextField!
    
    @IBAction func trySignUp(_ sender: Any) {
        if enterUsername.text! == ""{
            CSRMethods.app.showAlert(titleMessage: "CSR Alert", messageString: "Username has no entry")
        }
        
        if enterEmail.text! == "" {
            CSRMethods.app.showAlert(titleMessage: "CSR Alert", messageString: "Username has no entry")
        }
        
        if enterPassword.text! == "" {
            CSRMethods.app.showAlert(titleMessage: "CSR Alert", messageString: "Password has no entry")
        }
        if confirmPassword.text! == "" {
            CSRMethods.app.showAlert(titleMessage: "CSR Alert", messageString: "Confirm password has no entry")
        }
        if confirmPassword.text! != enterPassword.text! {
            CSRMethods.app.showAlert(titleMessage: "CSR Alert", messageString: "Passwords do not match")
        }
        
        UserDefaults.standard.set(enterUsername.text!, forKey: "username")
        
        CSRMethods.app.signUp(username: enterUsername.text!, email: enterEmail.text!, password: enterPassword.text!)
    }
    
}

