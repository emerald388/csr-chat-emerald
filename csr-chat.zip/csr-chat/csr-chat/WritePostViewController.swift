//
//  WritePostViewController.swift
//  csr-chat
//
//  Created by Brandon Sugarman on 5/23/19.
//  Copyright © 2019 Brandon Sugarman. All rights reserved.
//

import UIKit
import Firebase
class WritePostViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    var ref: DatabaseReference!
    
    var post: String!
    
    @IBAction func tryPost(_ sender: Any) {
        let username = UserDefaults.standard.string(forKey: "username")
        
        ref = Database.database().reference().child("posts")
        
        let key = ref.childByAutoId().key
        
        post = self.postTextView.text!
        
        let newPost = [
            key : username! + " : " + post
        ]
        
        ref.updateChildValues(newPost)
        
        
        CSRMethods.app.changeScreens(id: "newsfeed")
        
    }
    
    @IBOutlet weak var postTextView: UITextView!
    
    
    @IBOutlet weak var darkModeSwitch: UISwitch!
    
    
    @IBAction func darkModeOn(_ sender: Any) {
        if darkModeSwitch.isOn {
            view.backgroundColor = UIColor.init(red: 55/255.0, green: 55/255.0, blue: 55/255.0, alpha: 1)
        } else {
            view.backgroundColor = UIColor.init(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 1)
        }
    }
    
    
    
}
