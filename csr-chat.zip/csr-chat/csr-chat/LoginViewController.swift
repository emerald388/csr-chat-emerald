//
//  LoginViewController.swift
//  csr-chat
//
//  Created by Brandon Sugarman on 5/23/19.
//  Copyright © 2019 Brandon Sugarman. All rights reserved.
//

import UIKit
import Firebase
class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var inputUsername: UITextField!
    
    @IBOutlet weak var inputEmail: UITextField!
    
    @IBOutlet weak var inputPassword: UITextField!
    
    @IBAction func tryLogin(_ sender: Any) {
        if inputUsername == nil{
            CSRMethods.app.showAlert(titleMessage: "CSR Alert", messageString: "Username has no entry")
        }
        
        if inputEmail == nil {
            CSRMethods.app.showAlert(titleMessage: "CSR Alert", messageString: "Username has no entry")
        }
        
        if inputPassword == nil {
            CSRMethods.app.showAlert(titleMessage: "CSR Alert", messageString: "Password has no entry")
            
        }
        UserDefaults.standard.set(inputUsername.text!, forKey: "username")
        
        CSRMethods.app.login(username: inputUsername.text!, email: inputEmail.text!, password: inputPassword.text!)
        
    }
    
    @IBAction func goBack(_ sender: Any) {
        CSRMethods.app.changeScreens(id: "home")
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
